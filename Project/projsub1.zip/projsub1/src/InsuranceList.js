import React, { useEffect, useState } from 'react';
import { getInsurance } from './InsuranceService';

const InsuranceList = () => {
    const [insurances, setInsurances] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            const data = await getInsurance();
            setInsurances(data);
        };
        fetchData();
    }, []);
    if(!insurances.map) {
        return null;}
    
    return (
        <div>
            <h2>Insurance List</h2>
            <ul>
            
                {insurances.map(insurance => (
                    <li key={insurance.id}>
                        {insurance.name} - {insurance.type} - ${insurance.premium}
                    </li>
                ))}
            </ul>
        </div>
    );
   
};

export default InsuranceList;