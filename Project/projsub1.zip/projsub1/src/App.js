import React from 'react';
import InsuranceList from './InsuranceList';
import AddInsuranceForm from './AddInsuranceForm';
import Header from './Header';
import Footer from './Footer';

function App() {
    return (
        <div>
            <Header></Header>
          
            <h1>Insurance Management</h1>
            <AddInsuranceForm />

            <Footer></Footer>
        
        </div>
    );
}


export default App;
<InsuranceList />