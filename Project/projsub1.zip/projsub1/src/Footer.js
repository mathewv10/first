import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <p>@Aug 2024 Cdac by Mathew G.E.</p>
    </footer>
  );
}

export default Footer;
