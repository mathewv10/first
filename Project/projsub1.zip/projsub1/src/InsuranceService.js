       import axios from 'axios';
       
       const API_URL = 'http://localhost:8080/api/insurance';
       
       const getInsurance = async () => {
           try {
               const response = await axios.get(API_URL);
               return response.data;
           } catch (error) {
               console.error("There was an error fetching insurance data!", error);
           }
       };
       
       const addInsurance = async (insurance) => {
           try {
               const response = await axios.post(API_URL, insurance);
               return response.data;
           } catch (error) {
               console.error("There was an error adding the insurance!", error);
           }
       };
       
       export { getInsurance, addInsurance };