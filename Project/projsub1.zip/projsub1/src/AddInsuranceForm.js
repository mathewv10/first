import React, { useState } from 'react';
import { addInsurance } from './InsuranceService';

const AddInsuranceForm = () => {
    const [name, setName] = useState('');
    const [type, setType] = useState('');
    const [premium, setPremium] = useState('');

    const handleSubmit = async (event) => {
        event.preventDefault();
        try{
        const newInsurance = { name, type, premium: parseFloat(premium) };
        await addInsurance(newInsurance);
        setName('');
        setType('');
        setPremium('');
        console.log("Response:", newInsurance.data); // Handle the response as needed  
        }
        catch (error) {
        console.error("Error:", error);
        }
        };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Add New Insurance</h2>
            <input 
                type="text" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Insurance Name" 
                required 
            />
            <input 
                type="text" 
                value={type} 
                onChange={(e) => setType(e.target.value)} 
                placeholder="Insurance Type" 
                required 
            />
            <input 
                type="number" 
                value={premium} 
                onChange={(e) => setPremium(e.target.value)} 
                placeholder="Premium" 
                required 
            />
            <button type="submit">Add Insurance</button>
        </form>
    );
};

export default AddInsuranceForm;