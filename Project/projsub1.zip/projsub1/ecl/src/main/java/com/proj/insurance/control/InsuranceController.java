package com.proj.insurance.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proj.insurance.model.Insurance;
import com.proj.insurance.serv.InsuranceService;

@RestController
@RequestMapping("/api/insurance")
public class InsuranceController {
    @Autowired
    private InsuranceService insuranceService;

    @GetMapping
    public List<Insurance> getAllInsurance() {
        return insuranceService.getAllInsurance();
    }

    @PostMapping
    public Insurance addInsurance(@RequestBody Insurance insurance) {
        return insuranceService.addInsurance(insurance);
    }

    @GetMapping("/{id}")
    public Insurance getInsuranceById(@PathVariable Long id) {
        return insuranceService.getInsuranceById(id);
    }
}
