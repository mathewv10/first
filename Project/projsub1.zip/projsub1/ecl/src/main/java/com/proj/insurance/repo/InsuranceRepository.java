package com.proj.insurance.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proj.insurance.model.Insurance;

public interface InsuranceRepository extends JpaRepository<Insurance,Long>  {

}
